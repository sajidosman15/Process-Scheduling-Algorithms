
package schedulingalgorithms;

public class Process {
    String name;
    double at;
    double st;
    double ct;
    double tat;
    double wt;
    double startingtime;
    int processing;
    int priroty;
    int executed=0;
    double remaining;
    double rrx;
    int id;
}
